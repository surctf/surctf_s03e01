package internal

const (
	InternalServerError = "Что-то пошло не так попробуйте еще раз..."
)
